﻿<?php
	// 数据库连接基本信息
	$db_host = "localhost";
	$db_user = "root";
	$db_pass = "123456";
	$db_name = "test";
	
	if(isset($_REQUEST['date'])) {
		// $date = "2014-7"
		$date = $_REQUEST['date'];
		
		
		// sql 语句
		// sql = "select sum(money) as sum , count(money) as count,left(datetime,7) as date  from donate where datetime < '2014-07-31 59:59:59' group by date";
		$query = "select sum(money) as sum , count(money) as count,left(datetime,7) as date  from donate where datetime < '$date-31 59:59:59' group by date";
		
		// 数据库连接
		$link = mysql_connect($db_host,$db_user,$db_pass);
		
		// select DB
		mysql_select_db($db_name,$link);	
		
		// 执行sql语句
		$rows = mysql_query($query,$link);
		
		// 将数据存入数据
		$datas = array();
		while($row = mysql_fetch_row($rows) ) {
			$datas[] = $row;
		}
		
		// 输出 json字符串
		// 实例
		// [["100","1","2013-12"],["475","11","2014-01"],["480","7","2014-02"],["342","10","2014-03"],["27","4","2014-04"]]
		echo json_encode($datas);
	} else {
		echo "error";
	}

?>