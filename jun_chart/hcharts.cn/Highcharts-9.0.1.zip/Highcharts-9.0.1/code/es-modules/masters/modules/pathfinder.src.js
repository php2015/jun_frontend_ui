/**
 * @license Highcharts Gantt JS v9.0.1 (2021-02-15)
 * @module highcharts/modules/pathfinder
 * @requires highcharts
 *
 * Pathfinder
 *
 * (c) 2016-2021 Øystein Moseng
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Gantt/Pathfinder.js';
