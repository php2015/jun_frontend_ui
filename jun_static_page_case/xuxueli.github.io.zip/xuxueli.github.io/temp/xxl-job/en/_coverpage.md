<img src="https://www.xuxueli.com/doc/static/xxl-job/images/xxl-logo.png" width="100" >

# XXL-JOB

> A lightweight distributed task scheduling framework.

- Simple、Lightweight、Extensibility

[GitHub](https://github.com/xuxueli/xxl-job/)
[Get Started](#_1-brief-introduction)