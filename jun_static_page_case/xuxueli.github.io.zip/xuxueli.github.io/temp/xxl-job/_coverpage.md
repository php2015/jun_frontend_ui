<img src="https://www.xuxueli.com/doc/static/xxl-job/images/xxl-logo.png" width="100" >

# XXL-JOB

> 分布式任务调度平台

- 开发迅速、学习简单、轻量级、易扩展

[GitHub](https://github.com/xuxueli/xxl-job/)
[Gitee](http://gitee.com/xuxueli0323/xxl-job)
[Get Started](#《分布式任务调度平台XXL-JOB》)