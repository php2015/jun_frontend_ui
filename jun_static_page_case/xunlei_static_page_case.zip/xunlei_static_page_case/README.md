## 旧版本迅雷的静态页面，使用html\css\js\jquery语言制作
 下方式图片展示（加载时间可能有点长） 
![输入图片说明](https://images.gitee.com/uploads/images/2020/0420/181253_26a0803b_4964818.jpeg "迅雷看看.jpg")
