#demo-bootstrap-LTE（网站后台管理模版）

#项目基本介绍：  
1.基于bootstrap框架  
2.基于bootstrap-LTE后台模版  

#包含插件：  
1.tablesorter插件：表格数据排序  
2.select2插件：模拟下拉框+搜索效果  
3.datepicker插件：时间插件  
4.邮箱自动补全提示  
5.城市联动插件  

#扩展js：  
1.验证处理  
2.cookie处理  
3.常用正则  
4.图片比例换算  


#参考  
用于页面具体布局（整套布局）  
AdminLTE-2.3.7.zip  
