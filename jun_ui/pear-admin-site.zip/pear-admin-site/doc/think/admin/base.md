## 发送邮件  :id=option

- 后台配置邮箱参数
> `go_mail(地址，标题，内容)`


## 系统配置  :id=method

- 获取后台配置标签
> `{:get_config('字段')}`
