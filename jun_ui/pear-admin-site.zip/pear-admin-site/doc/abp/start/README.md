## 设置启动项目  :id=setup
选择PearAdminAbpTemplateAdmin作为启动项目
![配置文件](README_files/4.png)

## 设置链接字符串  :id=connection
在appsetting.json中设置连接字符串
![配置文件](README_files/1.png)
![连接字符串](README_files/2.png)

## 执行数据库迁移  :id=migratioin
包管理控制台选择默认项目并执行迁移
![执行迁移](README_files/3.png)

## 启动项目  :id=start
VS直接启动项目即可
