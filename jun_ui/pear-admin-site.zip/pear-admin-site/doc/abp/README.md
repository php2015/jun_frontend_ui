## 更新日志   :id=log

> 当前版本：`pear admin abp 1.1.0.release`，更新于：`2021-01-17`，查看 [在线演示](http://net.pearadmin.com/)。


#### 2021-01-17 （ 1.1.0.release ）   :id=log_315
- [移除] 冗余文件
- [新增] 可迁移脚本
- [更改] 代码整理
