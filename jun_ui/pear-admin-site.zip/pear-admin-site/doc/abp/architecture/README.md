## 结构划分  :id=config
Pear Admin Abp 基于 AspNetBoilerplate 的快速开发平台，整体结构依照Abp自身项目提供。对上层应用层进行了更改，移除了Web.Host和Web.Core,更名原有Web.Mvc为Admin结尾,方便从上到下看起来顺畅。

![结构划分](README_files/1.png)

## 各层介绍  :id=layer
![各层介绍](README_files/2.png)

## 跨上下文调用
![跨上下文调用](README_files/3.png)