## 基本介绍

Pear Icon 在 layui 之外提供的一套字体图标设计


## 基本使用


#### 开发环境 

```html
<link rel="stylesheet" href="component/pear/css/pear.css">
```

#### 简单使用

```html
<i class="pear-icon pear-icon-add"></i>
```

`.pear-icon` 样式

`.pear-icon-xxx` 图标

详情：[前往](http://layui.pearadmin.com/view/document/icon.html)