#easyui-admin-template
技术支持：http://www.webplus.org.cn
演示：http://admintemplate.webplus.org.cn/
由于本模板用到了ajax异步加载，您必须使用web服务器承载才能正常查看效果。