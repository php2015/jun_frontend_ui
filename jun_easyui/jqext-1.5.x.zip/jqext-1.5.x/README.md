#jqext-1.5.x
jQuery && jEasyUI 扩展功能集合
该扩展功能基于 jQuery 2.x/3.x 和 jQuery EasyUI 1.5.x 实现
<hr />
jQuery EasyUI 1.5.2
Copyright (c) 2009-2017 www.jeasyui.com. All rights reserved.<br />
Licensed under the freeware license: <a target="_blank" href="http://www.jeasyui.com/license_freeware.php">http://www.jeasyui.com/license_freeware.php</a><br />
To use it on other terms please contact us: info@jeasyui.com<br />
<br />
The Freeware Edition is available under <a target="_blank" href="http://www.jeasyui.com/license_freeware.php">Freeware License</a>, you can use it in any freeware-licensed projects. Download jQuery EasyUI under freeware license.<br />
The Commercial Edition is also available under <a target="_blank" href="http://www.jeasyui.com/license_commercial.php">Commercial License</a>, you can use it in a commercial project.<br />
<hr />
<h3>使用本扩展前请仔细阅读本文件</h3>
<ul>
    <li>功能概述</li>
    <li>目录结构说明</li>
    <li>引用方式</li>
    <li>注意事项</li>
    <li>API 文档和示例程序</li>
    <li>其他</li>
</ul>
