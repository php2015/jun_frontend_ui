#基于dialog插件的扩展.(适用于Easyui 1.3.3+版本)

##在线DEMO
[DEMO](http://www.gson.cn/ext.easyui/ext.dialog/ext/demo.html)