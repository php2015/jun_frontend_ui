#扩展Tree的getLevel方法

##在线DEMO
[DEMO](http://www.gson.cn/ext.easyui/ext.tree/methods.getLevel/demo.html)