#Easyui 基于kindeditor的扩展 插件

Usage

```
<textarea class="easyui-kindeditor" style="width:100%;height:200px;visibility:hidden;">KindEditor</textarea>

或者

```
$("#kindeditor").kindeditor({....});