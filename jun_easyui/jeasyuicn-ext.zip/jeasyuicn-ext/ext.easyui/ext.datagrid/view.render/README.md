#重写Datagrid的默认View使其支持二级数据对象。列内容支持easyui组件。

##在线DEMO
[DEMO](http://www.gson.cn/ext.easyui/ext.datagrid/view.render/demo.html)