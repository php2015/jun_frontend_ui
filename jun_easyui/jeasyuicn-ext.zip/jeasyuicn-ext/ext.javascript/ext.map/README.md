#javascript模拟Map对象

###DEMO
```javascript
    var mp = new Map();
	mp.put("key","value");
	mp.size();
	mp.toString();
	mp.values();
	mp.entrySet()
	....
```