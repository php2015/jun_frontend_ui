## 序列化表单元素 (类似 '.serialize()' 方法) 返回 JSON 数据结构数据。

#Usage
```javascript
    var vals = $("#ff").serializeObj();
	$("#rs").text(JSON.stringify(vals));
```
	
##在线DEMO
[DEMO](http://www.gson.cn/ext.jQuery/ext.serializeObj/demo.html)