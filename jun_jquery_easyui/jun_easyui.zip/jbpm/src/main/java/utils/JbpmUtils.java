package utils;

import org.springframework.stereotype.Component;

@Component
public class JbpmUtils {

	// @Autowired
	// @Qualifier(value = "processEngine")
	// private ProcessEngine processEngine;
	//
	// /**
	// * 结束流程中的这个任务
	// *
	// * @param taskId
	// */
	// public void complete(String taskId) {
	// TaskService taskService = processEngine.getTaskService();
	// taskService.completeTask(taskId);
	// }

}
