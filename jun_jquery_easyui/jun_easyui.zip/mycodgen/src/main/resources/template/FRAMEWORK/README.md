codgen-${appLabel}子系统
