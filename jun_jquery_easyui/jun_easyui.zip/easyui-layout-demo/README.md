# easyui-layout-demo

![image](https://raw.githubusercontent.com/wuwz/easyui-layout-demo/master/demo2.png)
![image](https://raw.githubusercontent.com/wuwz/easyui-layout-demo/master/demo.png)
