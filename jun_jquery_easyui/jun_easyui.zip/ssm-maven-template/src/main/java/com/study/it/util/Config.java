package com.study.it.util;

public final class Config {
    public static final int[] MD5SALT=new int[]{3,8,12,13,20,23};
}
