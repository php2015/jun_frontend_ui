package com.virjar.ssmcodegen;

/**
 * 可执行jar,可以通过他在运行时来确定参数 Created by virjar on 16/7/24.
 */
public class ShellRunner {
    public static void main(String[] args) {

    }
}
