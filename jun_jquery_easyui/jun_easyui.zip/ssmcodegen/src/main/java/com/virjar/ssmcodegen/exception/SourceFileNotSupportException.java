package com.virjar.ssmcodegen.exception;

public class SourceFileNotSupportException extends CodegenException {

    /**
     * 
     */
    private static final long serialVersionUID = 7827880250251109808L;

    public SourceFileNotSupportException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public SourceFileNotSupportException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        // TODO Auto-generated constructor stub
    }

    public SourceFileNotSupportException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public SourceFileNotSupportException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public SourceFileNotSupportException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

}
