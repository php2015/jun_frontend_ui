#EasyuiGridEx
提交这个项目是因为想分享一下 使用easyui的一些心得。
这个demo拓展了 pagelist 和 grid控件，使得数据分页显示效果更加完美。
![输入图片说明](http://git.oschina.net/uploads/images/2015/1026/090801_05a4d6db_397832.png "在这里输入图片标题")