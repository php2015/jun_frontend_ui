import Footer from '../layout/footer.vue';

export default Footer; 