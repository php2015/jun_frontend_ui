import Badge from './badge.vue';
export default Badge;