import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {BrowserAnimationsModule, NoopAnimationsModule} from '@angular/platform-browser/animations';
import {HttpClientModule} from '@angular/common/http';

import {AppRoutingModule} from './app-routing.module';
import {PackageModule} from '../../projects/package/src/public-api';

// 组件
import {AppComponent} from './app.component';
import {HomeComponent} from './pages/home/home.component';
import {FormViewComponent} from './pages/home/form-view/form-view.component';

// 依赖
import {FormsModule} from '@angular/forms';
import {DragulaModule} from 'ng2-dragula';
import {NgZorroAntdModule, NZ_I18N, zh_CN} from 'ng-zorro-antd';
import {AceEditorModule} from 'ng2-ace-editor';
import {DelonUtilModule} from '@delon/util';
import {DelonFormModule} from '@delon/form';

// 配置 angular i18n **
import {registerLocaleData} from '@angular/common';
import zh from '@angular/common/locales/zh';

registerLocaleData(zh);

@NgModule({
    declarations: [AppComponent, HomeComponent, FormViewComponent],
    imports: [
        BrowserModule,
        AppRoutingModule,
        PackageModule,
        FormsModule,
        AceEditorModule,
        DelonUtilModule,
        BrowserAnimationsModule,
        NoopAnimationsModule,
        HttpClientModule,
        // 导入 ng-zorro-antd 模块
        NgZorroAntdModule,
        DragulaModule.forRoot(),
        DelonFormModule.forRoot()
    ],
    // 配置 ng-zorro-antd 国际化（文案 及 日期
    providers: [{provide: NZ_I18N, useValue: zh_CN}],
    bootstrap: [AppComponent]
})
export class AppModule {
}
