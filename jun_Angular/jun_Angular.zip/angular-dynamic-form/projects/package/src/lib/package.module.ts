import {NgModule} from '@angular/core';
import {PackageComponent} from './package.component';

@NgModule({
  declarations: [PackageComponent],
  imports: [],
  exports: [PackageComponent]
})
export class PackageModule {
}
