import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'lib-package',
  templateUrl: './package.component.html',
  styles: []
})
export class PackageComponent implements OnInit {
  simpleDrop: any;

  constructor() {
    this.simpleDrop = null;
  }

  ngOnInit() {
  }

}
