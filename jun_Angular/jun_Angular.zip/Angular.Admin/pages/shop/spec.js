define(['app.admin'], function (app) {
    app.controller('app.shop.spec', function ($scope) {
        $scope.message = '属性模块';
    });

});