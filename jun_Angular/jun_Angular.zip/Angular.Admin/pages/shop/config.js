define(['app.admin'], function (app) {
    app.controller('app.shop.config', function ($scope) {
        $scope.message = '配置模块';
    });

});