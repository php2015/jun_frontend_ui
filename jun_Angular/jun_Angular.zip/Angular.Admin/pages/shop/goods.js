define(['app.admin'], function (app) {
    app.controller('app.shop.goods', function ($scope) {
        $scope.message = '商品模块';
    });

});