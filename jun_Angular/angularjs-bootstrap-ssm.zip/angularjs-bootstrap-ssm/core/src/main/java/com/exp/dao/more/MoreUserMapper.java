package com.exp.dao.more;

import com.exp.model.more.MoreUser;

import java.util.List;
import java.util.Map;

/**
 * Created by P0015475 on 2015/9/11.
 */
public interface MoreUserMapper {
    List<MoreUser> getList(Map<String,Object> params);
}
