package com.exp.controller;

import com.exp.dao.RoleMapper;
import com.exp.dao.more.MoreRoleMapper;
import com.exp.model.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * Created by WangBin on 2015/9/11.
 */
@Controller
@RequestMapping("/role")
public class RoleController {
    @Autowired
    private RoleMapper roleMapper;
    @Autowired
    private MoreRoleMapper moreRoleMapper;

    @RequestMapping("/view")
    public String view() {
        return "role/list";
    }

    @RequestMapping("/editUI")
    public String editUI() {
        return "role/editUI";
    }

    @RequestMapping("/list")
    @ResponseBody
    public List<Role> list() {
        List<Role> roles = moreRoleMapper.getList();
        return roles;
    }

    @RequestMapping("/getRole/{id}")
    @ResponseBody
    public Role getRole(@PathVariable Integer id) {
        Role role = null;
        if (id != null) {
            role = roleMapper.selectByPrimaryKey(id);
        }
        return role;
    }

    @RequestMapping("/delete/{id}")
    @ResponseBody
    public boolean delete(@PathVariable Integer id) {
        roleMapper.deleteByPrimaryKey(id);
        return true;
    }

    @RequestMapping("/edit")
    @ResponseBody
    public boolean edit(Role role) {
        if (role.getId() != null) {
            roleMapper.updateByPrimaryKeySelective(role);
        } else {
            roleMapper.insertSelective(role);
        }
        return true;
    }
}
